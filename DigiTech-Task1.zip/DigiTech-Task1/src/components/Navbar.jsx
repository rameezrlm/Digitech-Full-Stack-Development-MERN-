import React from 'react'
import '../Styles/Navbar.css'
import logo from '../assets/logo.png'
export const Navbar = () => {
  return (
    <>
    <div className='nav-bar'>
        <img src={logo} alt="" />
        <ul>
            <li>Home</li>
            <li>Students</li>
            <li>Courses</li>
            <li>Profile</li>
        </ul>
    </div>
    </>
  )
}

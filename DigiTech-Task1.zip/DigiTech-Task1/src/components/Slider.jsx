import slider from '../assets/slider.png'
import '../Styles/Slider.css'
const Slider = () => {
  return (
    <div className='container'>
        <img src={slider} alt="" />
    </div>
  )
}

export default Slider
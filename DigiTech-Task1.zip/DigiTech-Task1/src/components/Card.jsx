import "../Styles/Card.css";

const Card = ({url,title,description}) => {
  return (
    <div className="card">
      <div className="img-div">
        <img
        src={url}
        alt=""
      />
      </div>
      <div className="content">
        <h3>{title}</h3>
        <p>{description}</p>
        <button>Get Details</button>
        <button>Add More</button>
      </div>
    </div>
  );
};

export default Card;

import './App.css'
import Card from './components/Card'
import Footer from './components/Footer'
import { Navbar } from './components/Navbar'
import Slider from './components/Slider'

function App() {
    return (
      <>
        <Navbar />
        <Slider />
        <div className="cards">
         {
          data.map((item,idx)=>
             <Card url={item.url} title={item.title} description={item.description}/>
          )
         }
        </div>
        <Footer/>
      </>
    )
}

const data = [
  {
    url: "https://cdn-icons-png.flaticon.com/512/3135/3135755.png",
    title: "Students Record",
    description: "View, search, and update the records of all enrolled students."
  },
  {
    url: "https://cdn-icons-png.flaticon.com/512/1055/1055646.png",
    title: "Attendance",
    description: "Track daily attendance of students and generate monthly reports."
  },
  {
    url: "https://cdn-icons-png.flaticon.com/512/3135/3135810.png",
    title: "Teachers",
    description: "Manage teacher profiles, subjects assigned, and schedules."
  },
  {
    url: "https://cdn-icons-png.flaticon.com/512/1256/1256650.png",
    title: "Courses",
    description: "Browse available courses, manage curriculum, and assign instructors."
  },
  {
    url: "https://cdn-icons-png.flaticon.com/512/2920/2920244.png",
    title: "Examinations",
    description: "Create exam schedules, upload results, and analyze performance."
  },
  {
    url: "https://cdn-icons-png.flaticon.com/512/2331/2331970.png",
    title: "Fees & Payments",
    description: "Check pending fees, generate invoices, and track payment history."
  }
];

export default App
